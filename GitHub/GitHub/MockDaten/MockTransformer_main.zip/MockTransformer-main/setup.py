import setuptools

setuptools.setup(
    name='mock_data_generator',
    version='0.0.1',
    description='Mock Data Generator',
    install_requires=[
        "apache-beam[gcp]==2.34.0",
        "Faker==11.1.0",
        "schwifty==2021.10.2",
        "dataclasses==0.6",
        "jsonpickle==2.0.0",
        "google-cloud-bigquery==2.31.0",
        "google-cloud-bigquery-storage==2.10.1",
        "mimesis==5.2.1"
    ],
    package_dir={'src': './', 'tests': 'tests'},
    packages=setuptools.find_packages(),
    test_suite="tests"
)
