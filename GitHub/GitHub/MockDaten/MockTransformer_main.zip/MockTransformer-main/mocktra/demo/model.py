from dataclasses import dataclass

from mocktra.common.models.writable import Writable


@dataclass
class Account(Writable):
    account_id: str = ""
    account_holder_id: str = ""
    account_holder_name: str = ""
    iban: str = ""
    bic: str = ""
    balance: str = ""
    currency_code: str = ""
    product_id: str = ""


@dataclass
class Product(Writable):
    product_id: str = ""
    product_name: str = ""
    product_desc: str = ""
    product_type: str = ""


@dataclass
class AccountHolder(Writable):
    account_holder_id: str = ""
    account_holder_type: str = ""
    title: str = ""
    first_name: str = ""
    last_name: str = ""
    birth_name: str = ""
    date_of_birth: str = ""
    place_of_birth: str = ""
    phone_number: str = ""
    email: str = ""
    country: str = ""
    zip_code: str = ""
    city: str = ""
    street: str = ""
    house_number: str = ""
    address_type: str = ""


@dataclass
class Transaction(Writable):
    account_id: str = ""
    transaction_id: str = ""
    reason_for_payment: str = ""
    transaction_text: str = ""
    amount: str = ""
    number_of_decimals: str = ""
    direction: str = ""
    currency_code: str = ""
    booking_status: str = ""
    booking_date: str = ""
    value_date: str = ""
    is_returnable: str = ""
