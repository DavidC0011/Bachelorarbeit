"""Define commonly used static parameter."""
from enum import Enum


class GenderDistribution(Enum):
    MALE = 0.5
    FEMALE = 0.5


class BvDistribution(Enum):
    TRUE = 0.2
    FALSE = 0.8


class IsLegalRepresentative(Enum):
    TRUE = 0.05
    FALSE = 0.95


class IsGroupAccount(Enum):
    TRUE = 0.2
    FALSE = 0.8
