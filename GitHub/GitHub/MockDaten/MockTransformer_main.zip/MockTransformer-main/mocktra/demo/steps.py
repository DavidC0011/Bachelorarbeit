from datetime import datetime
from random import Random
from faker import Faker
from mimesis import Text, Food, Datetime
from mimesis.enums import Locale
from mimesis.typing import DateTime
from schwifty import IBAN

from mocktra.common.helpers import random_choice
from mocktra.common.operators.mock_operators import GenerateDomainEntity, GenerateDomainEntityFrom, JoinDomainEntities, \
    DomainEntityClone, GenerateNDomainEntitiesFromOne, GenerateNDomainEntitiesForOne
from mocktra.demo.fake_distributions import GenderDistribution
from mocktra.demo.model import Product, Account, AccountHolder, Transaction


class GenerateProducts(GenerateDomainEntity):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def generate(self, seed) -> Product:
        # seeding Faker instance which exists for each operator
        Faker.seed_instance(self.faker, seed)

        # generating a simple domain entity
        return Product(
            product_id=str(seed),
            product_name=self.faker.catch_phrase(),
            product_desc=self.faker.text()
        )


class GenerateAccountHolders(GenerateDomainEntity):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def generate(self, seed) -> AccountHolder:
        # seeding Faker and Random
        Faker.seed_instance(self.faker, seed)
        self.rand.seed(seed)

        # generating an account holder demonstrating more complex domain data types
        account_holder = AccountHolder()
        account_holder.account_holder_id = str(seed)
        account_holder.account_holder_type = "GROUP" if random_choice(self.rand, GenderDistribution, 1)[0] else "PERSON"
        account_holder.title = ""
        account_holder.first_name = self.faker.first_name_male() \
            if random_choice(self.rand, GenderDistribution, 1)[0] == GenderDistribution.MALE \
            else self.faker.first_name_female()
        account_holder.last_name = self.faker.last_name()
        account_holder.birth_name = account_holder.last_name
        account_holder.date_of_birth = f'{self.faker.date_between_dates(date_start=datetime(1900, 1, 1), date_end=datetime(2002, 1, 1)):%Y-%m-%d}'
        account_holder.place_of_birth = self.faker.city()
        account_holder.phone_number = self.faker.phone_number()
        account_holder.email = f'{account_holder.first_name}.{account_holder.last_name}@gmail.com'.replace(
            ' ', '.').lower()
        account_holder.country = "GERMANY"
        account_holder.zip_code = self.faker.postcode()
        account_holder.city = self.faker.city()
        account_holder.street = self.faker.street_name()
        account_holder.house_number = self.faker.building_number()
        account_holder.address_type = "PRIVATE"
        return account_holder


# TODO: Not used for performance reasons and logical complexity.
class JoinProductWithAccountHolder(JoinDomainEntities):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def right_key(self, account_holder: AccountHolder):
        return account_holder.account_holder_id

    def left_key(self, product: Product):
        return product.product_id


class MapAccountHolderToAccount(GenerateDomainEntityFrom):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def generate_from(self, account_holder: AccountHolder):
        self.rand.seed(account_holder.account_holder_id)
        Faker.seed_instance(self.faker, account_holder.account_holder_id)

        # Every entity is reproducible when using seeded random value generators.
        # Therefore, we can reproduce entities in steps for other entities.
        product_id = str(self.rand.randint(0, self.config.products - 1))

        account = Account()
        account.account_id = product_id + account_holder.account_holder_id
        account.account_holder_id = product_id + "_holder"
        account.account_holder_name = account_holder.first_name + " " + account_holder.last_name
        account.iban = self.faker.iban()
        account.bic = IBAN(account.iban).bic
        account.balance = str(self.rand.randint(-2000, 2000000000))
        account.currency_code = "EUR"
        account.product_id = product_id
        return account


class MapAccountToTransactions(GenerateNDomainEntitiesFromOne):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def generate_from_clone(self, account_clone: DomainEntityClone):
        clone_id = account_clone.clone_id
        account: Account = account_clone.domain_entity

        rand: Random = Random(account.account_id+str(clone_id))
        Faker.seed_instance(self.faker, account.account_id+str(clone_id))

        trx = Transaction()
        trx.transaction_id = account.account_id+str(clone_id)
        trx.reason_for_payment = self.faker.catch_phrase()
        trx.transaction_text = self.faker.text()
        trx.amount = rand.randint(1, 20000)
        trx.number_of_decimals = "2"
        trx.direction = "DEBIT"
        trx.currency_code = account.currency_code
        trx.booking_status = "BOOKED"
        trx.booking_date = f'{self.faker.date_between_dates(date_start=datetime(1900, 1, 1), date_end=datetime(2002, 1, 1)):%Y-%m-%d}'
        trx.value_date = f'{self.faker.date_between_dates(date_start=datetime(1900, 1, 1), date_end=datetime(2002, 1, 1)):%Y-%m-%d}'
        trx.is_returnable = str(rand.choice(["True", "False"]))
        return trx


class GenerateTransactionsForAccount(GenerateNDomainEntitiesForOne):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def generate_from(self, account: Account, index: int):
        rand: Random = Random(account.account_id+str(index))
        Faker.seed_instance(self.faker, account.account_id+str(index))

        trx = Transaction()
        trx.transaction_id = account.account_id+str(index)
        trx.reason_for_payment = self.faker.catch_phrase()
        trx.transaction_text = self.faker.text()
        trx.amount = rand.randint(1, 20000)
        trx.number_of_decimals = "2"
        trx.direction = "DEBIT"
        trx.currency_code = account.currency_code
        trx.booking_status = "BOOKED"
        trx.booking_date = f'{self.faker.date_between_dates(date_start=datetime(1900, 1, 1), date_end=datetime(2002, 1, 1)):%Y-%m-%d}'
        trx.value_date = f'{self.faker.date_between_dates(date_start=datetime(1900, 1, 1), date_end=datetime(2002, 1, 1)):%Y-%m-%d}'
        trx.is_returnable = str(rand.choice(["True", "False"]))
        return trx


class GenerateMimesisTrxForAccount(GenerateNDomainEntitiesForOne):

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def generate_from(self, account: Account, index: int):
        seed = account.account_id+str(index)
        self.rand.seed(seed)

        self.text.reseed(seed)
        self.food.reseed(seed)
        self.time.reseed(seed)

        trx = Transaction()
        trx.transaction_id = account.account_id+str(index)
        trx.reason_for_payment = self.text.level() + " " + self.food.dish()
        trx.transaction_text = self.text.text()
        trx.amount = self.rand.randint(1, 20000)
        trx.number_of_decimals = "2"
        trx.direction = "DEBIT"
        trx.currency_code = account.currency_code
        trx.booking_status = "BOOKED"
        self.time.date(start=1900, end=2021).__format__("%Y-%m-%d")
        trx.booking_date = self.time.date(start=1900, end=2021).__format__("%Y-%m-%d")
        trx.value_date = self.time.date(start=1900, end=2021).__format__("%Y-%m-%d")
        trx.is_returnable = str(self.rand.choice(["True", "False"]))
        return trx
