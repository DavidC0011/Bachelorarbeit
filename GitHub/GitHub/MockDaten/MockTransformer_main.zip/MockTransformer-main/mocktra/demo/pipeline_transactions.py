import os
import sys
from argparse import ArgumentParser

from apache_beam import Pipeline, ParDo
from apache_beam.options.pipeline_options import PipelineOptions

from mocktra.common.defaults import default_parameters
from mocktra.common.helpers import timed
from mocktra.common.models.writable import CSVWriter, CSVReader
from mocktra.common.operators.sink_operators import DumpMocks, LoadMocks
from mocktra.demo.model import Account, Transaction
from mocktra.demo.steps import MapAccountToTransactions, GenerateTransactionsForAccount


def read_parameters(argv: str):
    """Define pipeline parameter"""
    parser = default_parameters(ArgumentParser())  # NOSONAR, nosec

    parser.add_argument('--account_path',
                        required=False,
                        dest='account_path',
                        default='account_path',
                        type=str,
                        help='path to accounts')

    parser.add_argument('--transactions',
                        required=False,
                        dest='transactions',
                        default=10,
                        type=int,
                        help='number of transactions per account')

    return parser.parse_known_args(argv)


@timed
def run(argv=None):
    """Describe the pipeline-flow."""
    cfg, pipeline_args = read_parameters(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with Pipeline(options=pipeline_options) as pipeline:
        account_mock(cfg, pipeline)


def account_mock(cfg, pipeline):
    print("Reading from " + os.path.abspath(cfg.account_path))
    print("Dumping to " + os.path.abspath(cfg.out))
    print("Creating " + str(cfg.transactions) + " Transactions per Account")
    print("---------------------")
    accounts = pipeline | LoadMocks(model_type=Account, reader=CSVReader(quote_char="\""), input_dir=cfg.account_path)

    trx = accounts | "Generate Transactions" >> ParDo(GenerateTransactionsForAccount(n=cfg.transactions))
    trx | "Dump Transactions" >> DumpMocks(Transaction, writer=CSVWriter(), config=cfg)
    print("Built execution graph!")


if __name__ == '__main__':
    run(sys.argv)
