import os
import sys
from argparse import ArgumentParser

from apache_beam import Pipeline, Create, ParDo
from apache_beam.options.pipeline_options import PipelineOptions

from mocktra.common.defaults import default_parameters
from mocktra.common.helpers import timed
from mocktra.common.models.writable import CSVWriter
from mocktra.common.operators.sink_operators import DumpMocks
from mocktra.demo.model import Product, AccountHolder, Account
from mocktra.demo.steps import GenerateProducts, GenerateAccountHolders, MapAccountHolderToAccount


def read_parameters(argv: str):
    """Define pipeline parameter"""
    parser = default_parameters(ArgumentParser())  # NOSONAR, nosec

    parser.add_argument('--accounts',
                        required=False,
                        dest='accounts',
                        default=100,
                        type=int,
                        help='number of accounts')

    parser.add_argument('--products',
                        required=False,
                        dest='products',
                        default=10,
                        type=int,
                        help='number of products')

    return parser.parse_known_args(argv)


@timed
def run(argv=None):
    """Describe the pipeline-flow."""
    cfg, pipeline_args = read_parameters(argv)
    pipeline_options = PipelineOptions(pipeline_args)

    with Pipeline(options=pipeline_options) as pipeline:
        account_mock(cfg, pipeline)


def account_mock(cfg, pipeline: Pipeline):
    print("Dumping to " + os.path.abspath(cfg.out))
    print("Creating " + str(cfg.products) + " Products")
    print("Creating " + str(cfg.accounts) + " Accounts")
    print("---------------------")
    products = pipeline | "Create Products" >> Create(range(0, cfg.products)) | ParDo(GenerateProducts(cfg))
    account_holders = pipeline | "Create Accounts" >> Create(range(0, cfg.accounts)) | ParDo(GenerateAccountHolders(cfg))
    accounts = account_holders | ParDo(MapAccountHolderToAccount(cfg))

    products | "Dump Products" >> DumpMocks(Product, writer=CSVWriter(), config=cfg)
    account_holders | "Dump AccountHolders" >> DumpMocks(AccountHolder, writer=CSVWriter(), config=cfg)
    accounts | "Dump Accounts" >> DumpMocks(Account, writer=CSVWriter(), config=cfg)
    print("Built execution graph!")


if __name__ == '__main__':
    run(sys.argv)
