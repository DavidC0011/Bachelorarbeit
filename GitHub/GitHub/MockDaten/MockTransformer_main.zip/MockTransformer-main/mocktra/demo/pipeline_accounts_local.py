import sys
from argparse import ArgumentParser
from typing import List

from mocktra.common.defaults import default_parameters
from mocktra.common.models.writable import CSVWriter
from mocktra.demo.model import Product, AccountHolder, Account
from mocktra.demo.steps import GenerateProducts, GenerateAccountHolders, MapAccountHolderToAccount


def read_parameters(argv: str):
    """Define pipeline parameter"""
    parser = default_parameters(ArgumentParser())  # NOSONAR, nosec

    parser.add_argument('--accounts',
                        required=False,
                        dest='accounts',
                        default=100,
                        type=int,
                        help='number of accounts')

    parser.add_argument('--products',
                        required=False,
                        dest='products',
                        default=10,
                        type=int,
                        help='number of products')

    parser.add_argument('--transactions',
                        required=False,
                        dest='transactions',
                        default=10,
                        type=int,
                        help='number of transactions per account')

    return parser.parse_known_args(argv)

def run(argv=None):
    cfg, pipeline_args = read_parameters(argv)

    products: List[Product] = [GenerateProducts().generate(x) for x in range(cfg.products)]
    product_strings = [p.write(writer=CSVWriter()) for p in products]

    with open("./"+cfg.out+"/products.csv", "w") as file:
        file.writelines(product_strings)

    account_holders: List[AccountHolder] = [GenerateAccountHolders().generate(x) for x in range(cfg.accounts)]
    accounts: List[Account] = [MapAccountHolderToAccount().generate_from(holder) for holder in account_holders]
    account_strings = [a.write(writer=CSVWriter()) for a in accounts]
    with open("./"+cfg.out+"/accounts.csv", "w") as file:
        file.writelines(account_strings)


if __name__ == '__main__':
    run(sys.argv)