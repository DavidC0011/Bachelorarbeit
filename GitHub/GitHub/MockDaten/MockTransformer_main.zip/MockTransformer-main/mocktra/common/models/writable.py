import csv
import io
from abc import ABC, abstractmethod
from functools import reduce
from json import dumps, loads

import jsonpickle


class Writable:

    def __str__(self):
        return self.write(JSONWriter())

    def write(self, writer) -> str:
        return writer.write(self)

    def read(self, text, reader):
        return reader.read(text, self)


def to_camel_case(name):
    """Conversion from infix underscores to camel case"""
    splits = name.split("_")
    first = splits[0]
    concatenated = reduce((lambda x, y: x + (y.capitalize() if y else "")), splits[1:], first)
    return concatenated


def rename_keys_in_list(f_rename, to_list):
    result = []
    for value in to_list:
        if isinstance(value, list):
            result.append(rename_keys_in_list(f_rename, value))
        elif isinstance(value, dict):
            result.append(rename_keys(f_rename, value))
        else:
            result.append(value)
    return result


def rename_keys(f_rename, dictionary):
    result = dict()
    for key, value in dictionary.items():
        result[f_rename(key)] = value
        if isinstance(value, dict):
            result[f_rename(key)] = rename_keys(f_rename, value)
        elif isinstance(value, list):
            result[f_rename(key)] = rename_keys_in_list(f_rename, value)
    return result


def to_underscore_separation(name):
    result = reduce(lambda temp_result, head:
                    temp_result + ("_" + head.lower() if (not head.islower() and head.isalpha()) else head),
                    name, "")
    return result


class Writer(ABC):

    @abstractmethod
    def file_extension(self) -> str:
        pass  # NOSONAR

    @abstractmethod
    def write(self, model_object: Writable) -> str:
        pass  # NOSONAR


class Reader(ABC):

    @abstractmethod
    def file_extension(self) -> str:
        pass  # NOSONAR

    @abstractmethod
    def read(self, line: str, model_object) -> Writable:
        pass  # NOSONAR


def remove_pyobject(object_dict):
    result = dict()
    for key, value in object_dict.items():
        if key != 'py/object':
            if isinstance(value, dict):
                result[key] = remove_pyobject(value)
            elif isinstance(value, list):
                result[key] = [remove_pyobject(v) for v in value]
            else:
                result[key] = value
    return result


class JSONWriterGeneric(Writer):

    def file_extension(self) -> str:
        return "json"

    def __init__(self, camel_case_keys=True):
        self.camel_case_keys = camel_case_keys

    def write(self, model_object: Writable):
        model_dict = self.model_object_to_dict(model_object)
        return dumps(model_dict)

    def model_object_to_dict(self, model_object: Writable):
        result = dict()
        for key, value in model_object.__dict__.items():
            result_key = key
            if self.camel_case_keys:
                result_key = to_camel_case(key)
            if isinstance(value, Writable):
                result[result_key] = self.model_object_to_dict(value)
            elif isinstance(value, list):
                result[result_key] = [self.model_object_to_dict(v) if isinstance(v, Writable) else v for v in value]
            elif isinstance(value, dict):
                result[result_key] = {k: self.model_object_to_dict(v) if isinstance(v, Writable) else v
                                      for k, v in value.items()}
            else:
                result[result_key] = value

        return result


class JSONWriter(Writer):

    def file_extension(self) -> str:
        return "json"

    def __init__(self, camel_case_keys=True, no_qualified_module=False):
        self.camel_case_keys = camel_case_keys
        self.no_qualified_module = no_qualified_module

    def write(self, model_object: Writable):
        line = jsonpickle.encode(model_object)
        if self.camel_case_keys:
            line = dumps(rename_keys(to_camel_case, loads(line)))
        if self.no_qualified_module:  # TODO: Temporary solution
            object_dict = loads(line)
            object_dict = remove_pyobject(object_dict)
            line = dumps(object_dict)
        return line


class JSONReader(Reader):

    def __init__(self, camel_case_keys=True):
        self.camel_case_keys = camel_case_keys

    def file_extension(self):
        return 'json'

    def read(self, line: str, model_object: Writable) -> Writable:
        if self.camel_case_keys:
            line = dumps(rename_keys(to_underscore_separation, loads(line)))
        return jsonpickle.decode(line)


class CSVWriter(Writer):

    def file_extension(self) -> str:
        return "csv"

    def write(self, model_object: Writable):
        output = io.StringIO()
        csv_writer = csv.writer(output, quoting=csv.QUOTE_ALL, lineterminator='')
        values = self.values_to_list(model_object)
        csv_writer.writerow(values)
        return output.getvalue()

    def values_to_list(self, model_object: Writable):
        values = []
        for value in vars(model_object).values():
            if isinstance(value, str):
                values.append(value.replace("\n", "\\n"))
            else:
                values.append(value)
        return values


class CSVReader(Reader):
    """Only meant to be used with flat data structures."""

    def __init__(self, quote_char):
        self.quote_char = quote_char

    def file_extension(self) -> str:
        return "csv"

    def read(self, line: str, model_object: Writable) -> Writable:
        line = line.replace("\\n", "\n")
        reader = csv.reader([line], delimiter=',', quotechar=self.quote_char, lineterminator="\n",
                            quoting=csv.QUOTE_MINIMAL)
        row = next(reader)
        i = 0
        model_dict = dict()
        for key, _ in vars(model_object).items():
            model_dict[key] = row[i]
            i += 1
        model_object.__dict__.update(model_dict)
        return model_object
