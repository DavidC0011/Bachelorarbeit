from argparse import ArgumentParser


def default_parameters(parser: ArgumentParser):
    """Define pipeline parameter"""
    parser.add_argument('--out',
                        required=False,
                        dest='out',
                        default='mocks',
                        help='output directory')
    return parser
