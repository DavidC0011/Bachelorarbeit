"""Helper Functions and config-parameter."""
