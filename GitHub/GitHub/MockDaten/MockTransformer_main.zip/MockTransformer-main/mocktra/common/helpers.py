"""Helper Functions."""
import enum
import random
import string
import time

DATEFORMAT = "%Y-%m-%d"
TIMESTAMPFORMAT = "%Y-%m-%dT%H:%M:%SZ"


def timed(func):  # NOSONAR
    """Print the time elapsed for the decorated function."""

    def wrapper(*args, **kwargs):  # NOSONAR
        start = time.monotonic()
        result = func(*args, **kwargs)
        print('Mock data generator finished after (s): {}s'.format(time.monotonic() - start))
        return result

    return wrapper


def random_choice(rand: random.Random, choices: enum, count: int) -> list:
    """
    Generate a list of random values for a given enum respecting the weights.

    :param rand: seeded random generator
    :param choices: defined values for the random-list. The value of the enum defines the probability
    :param count: how many values will be generated
    """
    return rand.choices(population=list(choices), weights=[c.value for c in choices], k=count)  # nosec, NOSONAR (
    # random is not used for generating passwords)


def random_string(count: int, rand: random.Random, from_symbols: str = string.digits + string.ascii_uppercase) -> str:
    """
    Generate a list of random values for a given enum respecting the weights.

    :param count: how many chars the result string has
    :param rand: seeded random generator
    :param from_symbols: string containing the valid symbols. Default is digits + uppercase letters

    """
    return ''.join(rand.choice(from_symbols) for _ in range(count))  # nosec, NOSONAR (
    # random is not used for generating passwords)
