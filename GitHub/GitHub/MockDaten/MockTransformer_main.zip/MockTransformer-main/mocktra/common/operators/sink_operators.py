import os

import apache_beam as beam

from mocktra.common.models.writable import JSONWriter, JSONReader


class DumpMocks(beam.PTransform):

    def __init__(self, model_type, writer=JSONWriter(), config=None):
        super().__init__()
        self.typename = model_type.__name__.lower()
        self.writer = writer
        self.out = config.out

    def expand(self, input_or_inputs):
        return (input_or_inputs
                | f'{self.typename}:serialize' >> beam.Map(lambda element: element.write(self.writer))
                | f'{self.typename}:dump' >> beam.io.WriteToText(
                    f'{self.out}/{self.typename}.{self.writer.file_extension()}'))


class LoadMocks(beam.PTransform):

    def __init__(self, model_type, reader=JSONReader(), input_dir="./out"):
        super().__init__()
        self.typename = model_type.__name__.lower()
        self.type = model_type
        self.reader = reader
        self.input_dir = input_dir

    def expand(self, input_or_inputs):
        return input_or_inputs | (self.typename + ':load' >> beam.io.ReadFromText(
            f'{os.path.join(self.input_dir, self.typename)}.{self.reader.file_extension()}*')
                                  | self.typename + ':remove empty' >> beam.Filter(lambda text: text)
                                  | self.typename + ':deserialize' >> beam.Map(
                    lambda text: self.type().read(text, self.reader)))


class PublishMocks(beam.PTransform):

    def __init__(self, topic, typename, writer):
        super().__init__()
        self.topic = topic
        self.typename = typename
        self.writer = writer

    def expand(self, input_or_inputs):
        return (input_or_inputs
                | f'{self.typename}:tobytestring' >> beam.Map(lambda o: o.write(self.writer).encode('utf-8'))
                | f'{self.typename}:publish' >> beam.io.WriteToPubSub(topic=self.topic))
