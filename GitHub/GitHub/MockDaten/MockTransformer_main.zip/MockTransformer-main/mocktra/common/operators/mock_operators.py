import json
import os
from abc import ABC, abstractmethod
from random import Random

import apache_beam as beam
from apache_beam import DoFn, Flatten, ParDo
from apache_beam.io import PubsubMessage
from dataclasses import dataclass

from faker import Faker
from mimesis import Text, Food, Datetime, Person, Finance, Address, Choice

from mocktra.common.models.writable import Writable


class DeployCfg(beam.PTransform):

    def __init__(self, config):
        super().__init__()
        self.config = config

    def expand(self, input_or_inputs):
        return input_or_inputs | beam.Create([json.dumps(self.config.__dict__)]) \
               | beam.io.WriteToText(os.path.join(self.config.bucket, self.config.out, "config"))


class GeneratorDoFn(DoFn, ABC):

    def __init__(self, config=None, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)
        self.config = config
        self.rand = Random()
        self.address = Address()
        self.choice = Choice()
        self.finance = Finance()
        self.food = Food()
        self.person = Person()
        self.text = Text()
        self.time = Datetime()

    def seed(self, seed):
        self.rand.seed(seed)
        self.address.reseed(seed)
        self.choice.reseed(seed)
        self.finance.reseed(seed)
        self.food.reseed(seed)
        self.person.reseed(seed)
        self.text.reseed(seed)
        self.time.reseed(seed)


class GenerateDomainEntity(GeneratorDoFn, ABC):
    """
    Use an empty object and fill it with life.

    class EmployeeMock(BlankMock):

    def generate(self, config, seed, employee):
        employee.id = rand.randint(config.START_EMPLOYEE, config.END_EMPLOYEE)
        return employee
    """

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def to_runner_api_parameter(self, unused_context):
        return  # NOSONAR

    def process(self, element, *args, **kwargs):
        self.seed(element)
        yield self.generate(element)

    @abstractmethod
    def generate(self, seed) -> Writable:
        pass  # NOSONAR


class GenerateDomainEntityFrom(GeneratorDoFn, ABC):
    """
    Transform an input element to a new output element. Example:

    class EmployeeToIdentityMock(MapMock):

    def generate_from(self, employee: Employee):
        return Identity(
            identity_id=employee.identity_id,
            identity_alias=f'{employee.first_name}.{employee.last_name}.{employee.identity_id}@gcp.deuba.com')
    """

    def to_runner_api_parameter(self, unused_context):
        return  # NOSONAR

    def __init__(self, config=None, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)
        self.config = config

    def process(self, element, *args, **kwargs):
        yield self.generate_from(element)

    @abstractmethod
    def generate_from(self, element):
        """Uses an initially empty object as output that is populated in the process."""
        pass  # NOSONAR


class GenerateNDomainEntitiesFromOne(beam.PTransform):
    """
    Transform an input element to multiple output elements.

    def generate_from_clone(self, account_clone: Clone):
        account: Account = account_clone.value
        clone_id = account_clone.clone_id
        rand = Random(account.account_id + clone_id) !! important as otherwise duplicates are generated !!

        transaction = Transaction()
        transaction.account_id = account.account_id
        ...
        return transaction
    """

    def __init__(self, multiplier, clones_per_job=1000):
        super().__init__()
        self.multiplier = multiplier
        self.clones_per_job = clones_per_job
        self.rand = Random()
        self.faker = Faker("de_DE")

    def expand(self, elements):
        clones = elements
        remaining_clone_count = self.multiplier
        while True:
            if remaining_clone_count < self.clones_per_job:
                clones = clones | ParDo(CloneMocks(remaining_clone_count))
                break
            clones = clones | ParDo(CloneMocks(self.clones_per_job))
            remaining_clone_count -= self.clones_per_job

        return clones | beam.Map(self.generate_from_clone)

    @abstractmethod
    def generate_from_clone(self, element):
        """Uses an initially empty object as output that is populated in the process."""
        pass  # NOSONAR


class GenerateNDomainEntitiesForOne(GeneratorDoFn, ABC):
    """
    Transform an input element to multiple output elements.

    def generate_from_clone(self, account_clone: Clone):
        account: Account = account_clone.value
        clone_id = account_clone.clone_id
        rand = Random(account.account_id + clone_id) !! important as otherwise duplicates are generated !!

        transaction = Transaction()
        transaction.account_id = account.account_id
        ...
        return transaction
    """

    def __init__(self, n):
        super().__init__()
        self.n = n
        self.rand = Random()
        self.faker = Faker("de_DE")
        self.text = Text()
        self.food = Food()
        self.time = Datetime()

    def to_runner_api_parameter(self, unused_context):
        return  # NOSONAR

    def process(self, element, **kwargs):
        seed = self.define_seed(element)
        self.seed(seed)
        for i in range(self.n):
            yield self.generate_from(element, i)

    @abstractmethod
    def generate_from(self, element, index):
        """Uses an initially empty object as output that is populated in the process."""
        pass  # NOSONAR

    @abstractmethod
    def define_seed(self, element):
        """Define the seed so that the generators are only seeded once in the for-loop"""
        pass


@dataclass
class DomainEntityClone:
    clone_id: str
    domain_entity: object


class CloneMocks(DoFn):
    clones_per_job = 1

    def __init__(self, clones_per_job, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)
        self.clones_per_job = clones_per_job

    def to_runner_api_parameter(self, unused_context):
        pass

    def process(self, element, *args, **kwargs):
        for x in range(self.clones_per_job):
            if element is DomainEntityClone:
                clone = DomainEntityClone(clone_id=element.clone_id + ":" + str(x), domain_entity=element.domain_entity)
            else:
                clone = DomainEntityClone(clone_id=str(x), domain_entity=element)
            yield clone


class MapToManyMock(GeneratorDoFn, ABC):
    """
    Transform an input element to multiple output elements. Example:

    def map_many(self, product: Product):
        for _ in range(self.config.transactions):
            transaction = Transaction()
            // populate transaction fields
            yield transaction
    """

    def to_runner_api_parameter(self, unused_context):
        return  # NOSONAR

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    # TODO: Use SplittableDoFN
    def process(self, element, *args, **kwargs):
        for output in self.map_many(element):
            yield output

    @abstractmethod
    def map_many(self, element):
        """Uses an initially empty object as output that is populated in the process."""
        pass  # NOSONAR


class MapWithMock(beam.PTransform):

    def __init__(self, with_input: beam.PCollection):
        super().__init__()
        self.with_input = with_input

    def expand(self, input_or_inputs):
        return input_or_inputs | beam.Map(lambda element, with_list: self.map_with(element, with_list),
                                          with_list=beam.pvalue.AsList(self.with_input))

    def map_with(self, element, with_list):
        pass  # NOSONAR


class FilterMock(GeneratorDoFn, ABC):
    """
    Filter input elements based on a condition.

    class PartnerAccountToAssociatePartnerKMI(ConditionedMapMock):

        def condition(self, config, input):
            account, partner = input
            return partner.partner_type == "GROUP"
    """

    def to_runner_api_parameter(self, unused_context):
        pass  # NOSONAR

    def __init__(self, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)

    def process(self, element, *args, **kwargs):
        if self.condition(element):
            yield element

    @abstractmethod
    def condition(self, element) -> bool:
        pass  # NOSONAR


class SeparateMock(beam.PTransform, ABC):
    """
    Separate input elements based on a condition.

    class SeparateIdentityEven(SeparateMock):
        def condition(self, identity: Identity) -> bool:
            return len(identity.identity_id) % 2 == 0

    In Pipeline:
    outputs_false, outputs_true = identity_stream | SeparateIdentityEven()
    """

    def expand(self, input_or_inputs):
        input_or_inputs_true = input_or_inputs | "Filter True" >> beam.Filter(self.condition)
        input_or_inputs_false = input_or_inputs | "Filter False" >> beam.Filter(lambda e: not self.condition(e))
        return input_or_inputs_true, input_or_inputs_false

    @abstractmethod
    def condition(self, element) -> bool:
        pass  # NOSONAR


class JoinDomainEntities(beam.PTransform, ABC):
    """Pair up elements from two input collections (left, right).
    Elements are paired when left_key(left_element) matches right_key(right_element).
    Hence you only need to define left_key and right_key.
    The resulting stream contains pairs, where every pair consists of lists matching the respective type.

    class PartnerAccountPair(PairMocks):

    def __init__(self):
        super().__init__()
        self.left_name = "Partner"
        self.right_name = "Account"

    def left_key(self, partner: Partner):
        return partner.partner_id

    def right_key(self, account: Account):
        return account.account_holder_id"""

    def __init__(self, config=None):
        super().__init__()
        self.config = config
        self.left_name = ""
        self.right_name = ""

    def expand(self, inputs):
        join_name = self.left_name + self.right_name
        left, right = inputs
        left_map = left | f'{self.left_name}:toKeyValueMap' >> beam.Map(
            lambda element: (self.left_key(element), element))
        right_map = right | f'{self.right_name}:toKeyValueMap' >> beam.Map(
            lambda element: (self.right_key(element), element))
        return ({self.left_name: left_map, self.right_name: right_map}
                | f'{join_name}:JoinByKey' >> beam.CoGroupByKey()
                | f'{join_name}:FilterEmptyResults' >> beam.Filter(
                    lambda result: len(result[1][self.left_name]) > 0 and len(result[1][self.right_name]) > 0)
                | f'{join_name}:ToPair' >> beam.Map(self.get_values))

    def get_values(self, element):
        _, values = element
        if len(values[self.left_name]) != 1 or len(values[self.right_name]) != 1:
            raise PairMockException
        return values[self.left_name][0], values[self.right_name][0]

    @abstractmethod
    def left_key(self, element):
        pass  # NOSONAR

    @abstractmethod
    def right_key(self, element):
        pass  # NOSONAR


class PairMockException(Exception):
    """Resulting left and right lists do not have length 1."""
    pass


class UnionMocks(beam.PTransform):
    """
    The union operation is a concrete operator for flattening containers
    (e.g., tuples, lists in an input stream). Just use it!
    """

    def expand(self, input_or_inputs):
        return input_or_inputs | Flatten()


class EmitEvent(DoFn):

    def to_runner_api_parameter(self, unused_context):
        pass  # NOSONAR

    def __init__(self, config=None, *unused_args, **unused_kwargs):
        super().__init__(*unused_args, **unused_kwargs)
        self.config = config

    def process(self, element, *args, **kwargs):
        yield self.emit(element)

    @abstractmethod
    def emit(self, element) -> PubsubMessage:
        """Uses an initially empty object as output that is populated in the process."""
        pass  # NOSONAR
