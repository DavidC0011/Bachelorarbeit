def struct_equal_dict(dict1, dict2):
    """
    Test the structural equality of two dictionaries.
    Use this test as soon as you know how, for example, an event is structured
    as a JSON payload.
    Then check whether what is generated is structurally equal.
    """
    return struct_equal_dict_directed(dict1, dict2) and struct_equal_dict_directed(dict2, dict1)


def struct_equal_dict_directed(dict1, dict2):
    """
    Test whether every key in dict1 exists in dict2
    and values are structurally equal.
    """
    for key, value in dict1.items():
        if key not in dict2.keys():
            print(key + " not in dict2")
            return False
        value2 = dict2[key]
        if type(value) is not type(value2):
            print("type(" + key + ") does not match")
            return False
        if type(value) is dict:
            return struct_equal_dict_directed(value, value2)
        if type(value) is list:
            return struct_equal_list(key, value, value2)
    return True


def struct_equal_list(key, list1, list2):
    """
    Test where every element in list1 is structurally equal to list2.
    """
    if len(list1) != len(list2):
        print()
        return False
    for value, value2 in zip(list1, list2):
        if type(value) != type(value2):
            print("type(" + key + ") does not match")
            return False
        if isinstance(value, dict):
            return struct_equal_dict_directed(value, value2)
        if isinstance(value, list):
            return struct_equal_list(key, value, value2)
    return True
