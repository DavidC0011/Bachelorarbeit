"""Tests for the model classes."""
import os
from argparse import Namespace
from json import load
from unittest import TestCase

from mocktra.models import (rename_keys, to_camel_case,
                            to_underscore_separation, Writable, JSONWriter, CSVWriter, CSVReader)
from mocktra.models import TESTRESOURCES


class TestOutput(TestCase):
    """Tests for the model classes."""

    def test_camel_case(self):
        actual = to_camel_case("hello_world")
        expected = "helloWorld"
        self.assertEqual(expected, actual)

    def test_camel_case_start_underscore(self):
        actual = to_camel_case("_hello_world")
        expected = "HelloWorld"
        self.assertEqual(expected, actual)

    def test_camel_case_end_underscore(self):
        actual = to_camel_case("hello_world_")
        expected = "helloWorld"
        self.assertEqual(expected, actual)

    def test_camel_case_double_underscore(self):
        actual = to_camel_case("hello__world")
        expected = "helloWorld"
        self.assertEqual(expected, actual)

    def test_underscore_separation(self):
        actual = to_underscore_separation("helloWorld")
        expected = "hello_world"
        self.assertEqual(expected, actual)

    def test_underscore_separation_start(self):
        actual = to_underscore_separation("HelloWorld")
        expected = "_hello_world"
        self.assertEqual(expected, actual)

    def test_underscore_separation_end(self):
        actual = to_underscore_separation("helloWorlD")
        expected = "hello_worl_d"
        self.assertEqual(expected, actual)

    def test_rename_keys_to_underscores(self):
        with open(os.path.join(TESTRESOURCES, "transaction.json")) as f:
            camel_case_dict = load(f)
        with open(os.path.join(TESTRESOURCES, "transaction_underscores.json")) as f:
            underscores_dict = load(f)
        camel_case_dict_refactored = rename_keys(to_underscore_separation, camel_case_dict)
        self.assertEqual(underscores_dict, camel_case_dict_refactored)

    def test_rename_keys_to_camel_case(self):
        with open(os.path.join(TESTRESOURCES, "transaction.json")) as f:
            camel_case_dict = load(f)
        with open(os.path.join(TESTRESOURCES, "transaction_underscores.json")) as f:
            underscores_dict = load(f)
        underscores_dict_refactored = rename_keys(to_camel_case, underscores_dict)
        self.assertEqual(camel_case_dict, underscores_dict_refactored)

    def test_writable_str(self):
        test = Writable()
        actual = str(test)
        expected = '{"py/object": "models.writable.Writable"}'
        self.assertEqual(expected, actual)

    def test_writable_JSON(self):
        test = Writable()
        actual = test.write(JSONWriter())
        expected = '{"py/object": "models.writable.Writable"}'
        self.assertEqual(expected, actual)

    def test_writable_CSV(self):
        test = Writable()
        actual = test.write(CSVWriter())
        expected = ""
        self.assertEqual(expected, actual)

    def test_writable_CSV_newline(self):
        input_object = Namespace(text="hello\nworld")
        actual = CSVWriter().write(input_object)
        expected = '"hello\\nworld"'
        self.assertEqual(expected, actual)

    def test_read_CSV_newline(self):
        text = '"hello\\nworld"'
        expected = Namespace(text="hello\nworld")
        actual = CSVReader(quote_char='"').read(text, Namespace(text=""))
        self.assertEqual(expected, actual)
