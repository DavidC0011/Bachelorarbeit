docker build -t mocktra .

docker run --name mocktra -it --entrypoint "/bin/bash" --volume /d/docker_mocks:/mocks docker.io/library/mocktra