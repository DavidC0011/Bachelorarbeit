**Project Build Status** 

# MockTra - Generating Data through Data Transformation

MockTra creates test data that is consistent over multiple business entities for LPTs. 

## What will be generated?

![](docs/images/demo_model.png)

## Executing the generator

* Prequisites:
  * python 3.8
  * pip
  * perform `pip install .` in the project's folder

account_mock.py and account_to_transactions_mock.py work locally with a direct runner.
zvkk_mock.py only works with the dataflow runner.


=== Running the Data-Generator in the Cloud

NOTE: You should first follow the quick-start guide before running the generator in the cloud.

There is a script `run_zvkk_mock.sh` for deploying the pipeline in the cloud.
It is placed in the folder `scripts` in git.

[NOTE]
====
The script will be executed from the local machine.
Therefore a gcp-account with the appropriate rights is necessary.
====

== Configuring the Data Generator

The data-generator can be configured in terms of:

* gcs bucket
* output folder
* pubsub topic

=== What is configurable?

Configurations can be viewed in the respective read_parameters methods.

== Data consistency

To ensure consistency between several generations, a seed is used for any randomizer (including random+faker).

This ensures, that the generated Person with the ID X will be the same every time the generator is run.
Additionally, the postal-address and the relationships to the generated accounts will be the same.

This is extremely important for business events. If you want to write a pipeline, where there is a logical order
between events (not necessarily with regards to time), such consistency needs to be established.
Consider events with the order **Create** -> **Book** . You may want to generate **Create** events first
and test your system with the mocked events. In a stepwise manner, we can then have the respective
Book events later that are consistent with the Create events. Hence, reproducibility is a key property, which
is enabled by using seeded and thus pseudo-randomizers.


[[_TOC_]]

## Getting Started

### Prerequisites

To get the project up and running you need following tool on you local machine:

 - [install python](https://wiki.python.org/moin/BeginnersGuide/Download) 3.7 or greater 
 - [install pip](https://pip.pypa.io/en/stable/installing/)  
 - Use virtualenv for pip installs, e.g., do:
   ```
    virtualenv -p /usr/bin/python3.7 venv
    source venv/bin/activate
    pip install -r requirements.txt
    ```
 - Alternatively, use conda for pip installs, e.g., do:
    ```
    conda create -n mockdata python==3.8
    conda activate mockdata
    pip install -r requirements.txt
    ```
