# this has to be a registry that we can pull from. Thus, not working here.
IMAGE_URI=docker.io/library/mocktra

python -m mocktra.demo.pipeline_accounts \
  --runner=PortableRunner \
  --job_endpoint=localhost:3000  \
  --environment_type=DOCKER \
  --environment_config=${IMAGE_URI} \
  --products=100 \
  --accounts=10 \
  --transactions=100 \
  --out=./demoout \
  > error.txt 2>&1
