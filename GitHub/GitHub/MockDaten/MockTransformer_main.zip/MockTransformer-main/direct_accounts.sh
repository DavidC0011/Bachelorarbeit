python -m mocktra.demo.mimesis.pipeline_accounts --runner=DirectRunner --products=10 --accounts=200 --out=mocks/accounts #> error.txt 2>&1
